package com.unlovable.dynamic_app.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.unlovable.dynamic_app.model.EntitySchema
import com.unlovable.dynamic_app.model.PropertySchema
import com.unlovable.dynamic_app.util.Resource
import com.unlovable.dynamic_app.util.formatDisplayProperty
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicField(
    property: PropertySchema,
    value: JsonElement?,
    onValueChange: (Any?) -> Unit,
    getRelatedData: (String) -> StateFlow<Resource<List<JsonObject>>>,
    getRelatedSchema: (String) -> EntitySchema
) {
    val stringValue = if (value is JsonNull || value == null) "" else value.jsonPrimitive.content

    when (property.type) {
        "TEXT", "NUMBER" -> OutlinedTextField(
            value = stringValue,
            onValueChange = onValueChange,
            label = { Text(property.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        "TEXT_AREA" -> OutlinedTextField(
            value = stringValue,
            onValueChange = onValueChange,
            label = { Text(property.label) },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        "BOOLEAN" -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(property.label, modifier = Modifier.weight(1f))
            Switch(
                checked = value?.jsonPrimitive?.booleanOrNull ?: false,
                onCheckedChange = onValueChange
            )
        }
        "RELATIONSHIP" -> {
            var expanded by remember { mutableStateOf(false) }
            val relatedEntityName = property.relatedTo!!
            val relatedData by getRelatedData(relatedEntityName).collectAsState()
            val relatedSchema = getRelatedSchema(relatedEntityName)
            val items = (relatedData as? Resource.Success)?.data ?: emptyList()

            val selectedItemText = items.find { it[relatedSchema.primaryKey]?.jsonPrimitive?.content == stringValue }
                ?.formatDisplayProperty(relatedSchema)
                ?: "Select ${property.label}..."

            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = selectedItemText,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(property.label) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    items.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item.formatDisplayProperty(relatedSchema)) },
                            onClick = {
                                onValueChange(item[relatedSchema.primaryKey]!!.jsonPrimitive.content)
                                expanded = false
                            }
                        )
                    }
                    if (relatedData is Resource.Loading) {
                        DropdownMenuItem(text = { Text("Loading...") }, onClick = {}, enabled = false)
                    }
                }
            }
        }
    }
}