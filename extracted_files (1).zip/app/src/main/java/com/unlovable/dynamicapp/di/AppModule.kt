package com.unlovable.dynamic_app.di

import android.content.Context
import com.unlovable.dynamic_app.data.DynamicRepository
import com.unlovable.dynamic_app.model.AppSchema
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.serialization.json.Json
import java.io.InputStream
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideSupabaseClient(): SupabaseClient {
        return createSupabaseClient(
            supabaseUrl = "YOUR_SUPABASE_URL",
            supabaseKey = "YOUR_SUPERBASE_ANON_KEY"
        ) {
            install(GoTrue)
            install(Postgrest)
        }
    }

    @Provides
    @Singleton
    fun provideAppSchema(@ApplicationContext context: Context): AppSchema {
        val inputStream: InputStream = context.assets.open("schema.json")
        val jsonString = inputStream.bufferedReader().use { it.readText() }
        val json = Json { ignoreUnknownKeys = true }
        return json.decodeFromString(AppSchema.serializer(), jsonString)
    }

    @Provides
    @Singleton
    fun provideDynamicRepository(client: SupabaseClient): DynamicRepository {
        return DynamicRepository(client)
    }
}