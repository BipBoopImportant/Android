package com.unlovable.dynamic_app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.unlovable.dynamic_app.ui.components.*
import com.unlovable.dynamic_app.util.Resource

@Composable
fun EntityFormScreen(
    navController: NavController,
    entityName: String,
    entityId: String?,
    viewModel: EntityFormViewModel = hiltViewModel()
) {
    val formState by viewModel.formState.collectAsState()
    val entitySchema = viewModel.entitySchema
    val saveState by viewModel.saveState.collectAsState()

    LaunchedEffect(saveState) {
        if (saveState is Resource.Success) {
            navController.popBackStack()
        }
    }

    Scaffold(topBar = {
        AppTopBar(
            title = "${if (entityId != null) "Edit" else "New"} ${entitySchema.name}",
            navController = navController
        )
    }) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (val state = formState) {
                is Resource.Loading -> FullScreenLoading()
                is Resource.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(entitySchema.properties.filter { !it.isPrimaryKey }) { property ->
                            DynamicField(
                                property = property,
                                value = state.data?.get(property.name),
                                onValueChange = { viewModel.updateField(property.name, it) },
                                getRelatedData = { viewModel.getRelatedData(it) },
                                getRelatedSchema = { viewModel.getRelatedSchema(it) }
                            )
                        }
                        item {
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.save() },
                                enabled = saveState !is Resource.Loading,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Save") }
                            if (saveState is Resource.Loading) {
                                CircularProgressIndicator(modifier = Modifier.padding(top = 8.dp))
                            }
                            if (saveState is Resource.Error) {
                                Text(
                                    saveState?.message ?: "Error saving",
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }
                is Resource.Error -> FullScreenError(state.message ?: "Error")
            }
        }
    }
}