package com.unlovable.dynamic_app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unlovable.dynamic_app.ui.screens.*

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(navController)
        }
        composable(
            "list/{entityName}",
            arguments = listOf(navArgument("entityName") { type = NavType.StringType })
        ) {
            EntityListScreen(navController, it.arguments?.getString("entityName")!!)
        }
        composable(
            "form/{entityName}?id={entityId}",
            arguments = listOf(
                navArgument("entityName") { type = NavType.StringType },
                navArgument("entityId") { type = NavType.StringType; nullable = true }
            )
        ) {
            EntityFormScreen(
                navController,
                it.arguments?.getString("entityName")!!,
                it.arguments?.getString("entityId")
            )
        }
    }
}