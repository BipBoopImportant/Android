package com.unlovable.dynamic_app.ui.screens

import androidx.lifecycle.*
import com.unlovable.dynamic_app.data.DynamicRepository
import com.unlovable.dynamic_app.model.AppSchema
import com.unlovable.dynamic_app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

@HiltViewModel
class EntityListViewModel @Inject constructor(
    private val repo: DynamicRepository,
    schema: AppSchema,
    ssh: SavedStateHandle
) : ViewModel() {

    private val entityName: String = ssh.get<String>("entityName")!!
    val entitySchema = schema.entities.first { it.name == entityName }

    private val _listState = MutableStateFlow<Resource<List<JsonObject>>>(Resource.Loading())
    val listState = _listState.asStateFlow()

    private val _deleteState = MutableStateFlow<Resource<Unit>?>(null)
    val deleteState = _deleteState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            repo.getEntityList(entitySchema.tableName).collect { _listState.value = it }
        }
    }

    fun deleteItem(id: String) {
        viewModelScope.launch {
            repo.deleteEntity(entitySchema.tableName, id, entitySchema.primaryKey)
                .collect { _deleteState.value = it }
        }
    }
}