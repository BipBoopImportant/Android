package com.unlovable.dynamic_app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.unlovable.dynamic_app.ui.components.*
import com.unlovable.dynamic_app.util.Resource
import com.unlovable.dynamic_app.util.formatDisplayProperty
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

@Composable
fun EntityListScreen(
    navController: NavController,
    entityName: String,
    viewModel: EntityListViewModel = hiltViewModel()
) {
    val listState by viewModel.listState.collectAsState()
    val entitySchema = viewModel.entitySchema
    var showDeleteDialog by remember { mutableStateOf<String?>(null) }
    val deleteState by viewModel.deleteState.collectAsState()

    LaunchedEffect(deleteState) {
        if (deleteState is Resource.Success) {
            viewModel.refresh()
        }
    }

    ConfirmationDialog(
        show = showDeleteDialog != null,
        onDismiss = { showDeleteDialog = null },
        onConfirm = { showDeleteDialog?.let { viewModel.deleteItem(it) } },
        title = "Delete Item?",
        text = "Are you sure you want to permanently delete this item?"
    )

    Scaffold(
        topBar = { AppTopBar(title = entitySchema.pluralName, navController = navController) },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("form/${entityName}") }) {
                Icon(Icons.Default.Add, "Add Item")
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (val state = listState) {
                is Resource.Loading -> FullScreenLoading()
                is Resource.Success -> {
                    val data = state.data
                    if (data.isNullOrEmpty()) {
                        FullScreenError("No items found for ${entitySchema.pluralName}.")
                    } else {
                        LazyColumn(contentPadding = PaddingValues(8.dp)) {
                            items(data, key = { it[entitySchema.primaryKey].toString() }) { item ->
                                val pkValue = item[entitySchema.primaryKey]!!.jsonPrimitive.content
                                ListItem(
                                    headlineContent = { Text(item.formatDisplayProperty(entitySchema)) },
                                    modifier = Modifier.clickable { navController.navigate("form/${entityName}?id=${pkValue}") },
                                    trailingContent = {
                                        IconButton(onClick = { showDeleteDialog = pkValue }) {
                                            Icon(Icons.Default.Delete, "Delete")
                                        }
                                    }
                                )
                                Divider()
                            }
                        }
                    }
                }
                is Resource.Error -> FullScreenError(state.message ?: "An unknown error occurred.")
            }
        }
    }
}