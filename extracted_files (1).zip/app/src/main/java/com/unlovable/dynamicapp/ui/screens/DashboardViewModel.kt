package com.unlovable.dynamic_app.ui.screens

import androidx.lifecycle.ViewModel
import com.unlovable.dynamic_app.model.AppSchema
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(val schema: AppSchema) : ViewModel()