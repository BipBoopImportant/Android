package com.unlovable.dynamic_app.data

import com.unlovable.dynamic_app.util.Resource
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.*
import javax.inject.Inject

class DynamicRepository @Inject constructor(private val client: SupabaseClient) {

    private suspend fun ensureAuthenticated() {
        if (client.auth.currentUserOrNull() == null) {
            try {
                client.auth.signInWith(io.github.jan.supabase.gotrue.providers.builtin.Email) {
                    email = "test@example.com"
                    password = "password123"
                }
            } catch (e: Exception) {
                try {
                    client.auth.signUpWithEmail("test@example.com", "password123")
                } catch (e2: Exception) {
                    // User likely exists, and sign-in failed for another reason (e.g. network)
                    // The subsequent API call will fail and report the error, which is fine.
                }
            }
        }
    }

    private fun <T> apiCall(call: suspend () -> T): Flow<Resource<T>> = flow {
        emit(Resource.Loading())
        try {
            ensureAuthenticated()
            emit(Resource.Success(call()))
        } catch (e: Exception) {
            emit(Resource.Error(e.localizedMessage ?: "An unexpected API Error occurred"))
        }
    }

    fun getEntityList(table: String): Flow<Resource<List<JsonObject>>> = apiCall {
        client.postgrest.from(table).select().body.jsonArray.mapNotNull { it as? JsonObject }
    }

    fun getEntity(table: String, id: String, pkColumn: String): Flow<Resource<JsonObject?>> = apiCall {
        client.postgrest.from(table).select {
            filter { eq(pkColumn, id) }
        }.body.jsonArray.firstOrNull() as? JsonObject
    }

    fun saveEntity(table: String, data: Map<String, JsonElement>, pkColumn: String, id: String?): Flow<Resource<Unit>> = apiCall {
        if (id != null && id.isNotBlank()) {
            // Update
            client.postgrest.from(table).update(data) {
                filter { eq(pkColumn, id) }
            }
        } else {
            // Insert
            client.postgrest.from(table).insert(data)
        }
        Unit
    }

    fun deleteEntity(table: String, id: String, pkColumn: String): Flow<Resource<Unit>> = apiCall {
        client.postgrest.from(table).delete {
            filter { eq(pkColumn, id) }
        }
        Unit
    }
}