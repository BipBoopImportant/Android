package com.unlovable.dynamic_app.model

import kotlinx.serialization.Serializable

@Serializable
data class AppSchema(
    val appName: String,
    val entities: List<EntitySchema>
)

@Serializable
data class EntitySchema(
    val name: String,
    val pluralName: String,
    val tableName: String,
    val primaryKey: String,
    val displayProperty: String,
    val icon: String,
    val showOnDashboard: Boolean,
    val properties: List<PropertySchema>,
    val computedProperties: List<ComputedPropertySchema>? = null
)

@Serializable
data class PropertySchema(
    val name: String,
    val label: String,
    val type: String, // TEXT, NUMBER, BOOLEAN, DATE, RELATIONSHIP, TEXT_AREA, UUID
    val required: Boolean,
    val isPrimaryKey: Boolean = false,
    val isDisplay: Boolean = false,
    val relatedTo: String? = null
)

@Serializable
data class ComputedPropertySchema(
    val name: String,
    val label: String,
    val format: String,
    val isDisplay: Boolean = false
)