package com.unlovable.dynamic_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.unlovable.dynamic_app.ui.navigation.AppNavigation
import com.unlovable.dynamic_app.ui.theme.DynamicAppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DynamicAppTheme {
                AppNavigation()
            }
        }
    }
}