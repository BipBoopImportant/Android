package com.unlovable.dynamic_app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, viewModel: DashboardViewModel = hiltViewModel()) {
    val schema = viewModel.schema
    Scaffold(topBar = { TopAppBar(title = { Text(schema.appName) }) }) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(schema.entities.filter { it.showOnDashboard }) { entity ->
                DashboardButton(
                    text = entity.pluralName,
                    icon = getIcon(entity.icon),
                    onClick = { navController.navigate("list/${entity.name}") }
                )
            }
        }
    }
}

@Composable
private fun DashboardButton(text: String, icon: ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.aspectRatio(1f)) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = text, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(8.dp))
            Text(text)
        }
    }
}

fun getIcon(name: String): ImageVector = when (name) {
    "People" -> Icons.Default.People
    "RvHookup" -> Icons.Default.RvHookup
    "Checklist" -> Icons.Default.Checklist
    else -> Icons.Default.DataObject
}