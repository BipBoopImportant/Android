package com.unlovable.dynamic_app.util

import com.unlovable.dynamic_app.model.EntitySchema
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

fun JsonObject.formatDisplayProperty(schema: EntitySchema?): String {
    if (schema == null) {
        // Fallback if schema isn't available for some reason
        return this[this.keys.first()]?.jsonPrimitive?.contentOrNull ?: "N/A"
    }

    val computedProp = schema.computedProperties?.find { it.isDisplay }
    if (computedProp != null) {
        var formattedString = computedProp.format
        schema.properties.forEach { prop ->
            val value = this[prop.name]?.jsonPrimitive?.contentOrNull ?: ""
            formattedString = formattedString.replace("{${prop.name}}", value)
        }
        return formattedString
    }

    val displayProp = schema.properties.find { it.isDisplay }
        ?: schema.properties.firstOrNull { it.name == schema.displayProperty }
        ?: schema.properties.first()

    return this[displayProp.name]?.jsonPrimitive?.contentOrNull ?: "N/A"
}