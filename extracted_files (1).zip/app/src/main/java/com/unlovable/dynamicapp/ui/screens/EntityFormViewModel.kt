package com.unlovable.dynamic_app.ui.screens

import androidx.lifecycle.*
import com.unlovable.dynamic_app.data.DynamicRepository
import com.unlovable.dynamic_app.model.*
import com.unlovable.dynamic_app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class EntityFormViewModel @Inject constructor(
    private val repo: DynamicRepository,
    private val schema: AppSchema,
    ssh: SavedStateHandle
) : ViewModel() {

    private val entityName: String = ssh.get<String>("entityName")!!
    private val entityId: String? = ssh.get<String>("entityId")
    val entitySchema = schema.entities.first { it.name == entityName }

    private val _formState = MutableStateFlow<Resource<Map<String, JsonElement>>>(Resource.Loading())
    val formState = _formState.asStateFlow()

    private val _saveState = MutableStateFlow<Resource<Unit>?>(null)
    val saveState = _saveState.asStateFlow()

    private val relatedDataCache = mutableMapOf<String, StateFlow<Resource<List<JsonObject>>>>()

    init {
        if (entityId != null) {
            loadData()
        } else {
            _formState.value = Resource.Success(emptyMap())
        }
    }

    private fun loadData() = viewModelScope.launch {
        repo.getEntity(entitySchema.tableName, entityId!!, entitySchema.primaryKey).collect { res ->
            when (res) {
                is Resource.Success -> _formState.value = Resource.Success(res.data ?: emptyMap())
                is Resource.Error -> _formState.value = Resource.Error(res.message ?: "Failed to load")
                is Resource.Loading -> _formState.value = Resource.Loading()
            }
        }
    }

    fun updateField(key: String, value: Any?) {
        val currentData = (_formState.value as? Resource.Success)?.data?.toMutableMap() ?: mutableMapOf()
        val jsonValue = when (value) {
            is String -> JsonPrimitive(value)
            is Number -> JsonPrimitive(value)
            is Boolean -> JsonPrimitive(value)
            null -> JsonNull
            else -> JsonPrimitive(value.toString())
        }
        currentData[key] = jsonValue
        _formState.value = Resource.Success(currentData)
    }

    fun save() = viewModelScope.launch {
        val currentData = (_formState.value as? Resource.Success)?.data?.toMutableMap() ?: return@launch
        // Add primary key if it's a new entry and is a UUID
        val pkProperty = entitySchema.properties.find { it.isPrimaryKey }
        if (entityId == null && pkProperty?.type == "UUID") {
            currentData[entitySchema.primaryKey] = JsonPrimitive(UUID.randomUUID().toString())
        }
        repo.saveEntity(entitySchema.tableName, currentData, entitySchema.primaryKey, entityId)
            .collect { _saveState.value = it }
    }

    fun getRelatedData(relatedEntityName: String): StateFlow<Resource<List<JsonObject>>> {
        return relatedDataCache.getOrPut(relatedEntityName) {
            val relatedSchema = getRelatedSchema(relatedEntityName)
            repo.getEntityList(relatedSchema.tableName)
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Resource.Loading())
        }
    }

    fun getRelatedSchema(name: String) = schema.entities.first { it.name == name }
}