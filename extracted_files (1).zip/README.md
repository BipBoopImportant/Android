# DynamicApp - A Procedurally Generated Android Application

This project is a schema-driven, dynamic Android application. Its structure, data models, and UI are generated at runtime based on the configuration in `app/src/main/assets/schema.json`.

## How to Build

1.  Ensure all files from the source are placed in their correct directories.
2.  Make the Gradle wrapper script executable: `chmod +x gradlew`
3.  **Crucially, you must edit `app/src/main/java/com/unlovable/dynamic_app/di/AppModule.kt` and insert your own Supabase URL and Anon Key.**
4.  Run the build command from the root directory of this project: `./gradlew build` or `./gradlew assembleRelease`

The final, unsigned APK will be located at `app/build/outputs/apk/release/app-release-unsigned.apk`.

## How it Works

The entire application is defined by `app/src/main/assets/schema.json`. By modifying this file, you can change the application's functionality without writing new Kotlin code.

- **Entities**: Define new data objects (e.g., "Parts", "Employees").
- **Properties**: Define the fields for each entity (e.g., text, numbers, booleans, relationships to other entities).
- **Computed Properties**: Define display strings that combine multiple fields.

The Android application code is generic. It reads this schema and dynamically builds the dashboard, lists, and forms required to perform CRUD (Create, Read, Update, Delete) operations on any entity you define.